@echo off
REM Builds AudioReaderAI.exe  (needs Python 3.10+ installed, "Add to PATH" ticked)
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py -m PyInstaller --onefile --windowed --name AudioReaderAI --collect-all edge_tts --collect-all certifi app.py
echo.
echo Done! Your program is at: dist\AudioReaderAI.exe
pause
