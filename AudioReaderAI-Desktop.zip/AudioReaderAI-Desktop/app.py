"""AudioReader AI - Desktop edition.
Convert PDF / TXT / MD / DOCX files into MP3 audio using Microsoft Edge neural voices.
Needs an internet connection while generating (Edge voices run online)."""
import asyncio
import os
import re
import sys
import tempfile
import threading
import zipfile
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from xml.etree import ElementTree

import edge_tts

try:
    from pypdf import PdfReader
except ImportError:  # pragma: no cover
    PdfReader = None

FALLBACK_VOICES = [
    "en-US-AriaNeural", "en-US-AndrewNeural", "en-US-AvaMultilingualNeural",
    "en-US-JennyNeural", "en-US-GuyNeural", "en-GB-SoniaNeural", "en-GB-RyanNeural",
    "en-AU-NatashaNeural", "en-IN-NeerjaNeural", "en-IN-PrabhatNeural",
    "bn-BD-NabanitaNeural", "bn-BD-PradeepNeural", "es-ES-ElviraNeural", "fr-FR-DeniseNeural",
]
MAX_CHUNK = 4200


# ---------- text extraction ----------
def read_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        if PdfReader is None:
            raise RuntimeError("PDF support (pypdf) is not installed.")
        reader = PdfReader(path)
        return "\n\n".join((p.extract_text() or "") for p in reader.pages)
    if ext == ".docx":
        with zipfile.ZipFile(path) as z:
            root = ElementTree.fromstring(z.read("word/document.xml"))
        ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        paras = []
        for p in root.iter(ns + "p"):
            paras.append("".join(t.text or "" for t in p.iter(ns + "t")))
        return "\n".join(paras)
    for enc in ("utf-8-sig", "utf-16", "cp1252"):
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeError, UnicodeDecodeError):
            continue
    raise RuntimeError("Could not read this text file.")


def split_text(text: str, limit: int = MAX_CHUNK):
    text = re.sub(r"[ \t]+", " ", text.replace("\r", ""))
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks, cur = [], ""
    for s in sentences:
        while len(s) > limit:  # very long run-on sentence: hard split on spaces
            cut = s.rfind(" ", 0, limit)
            cut = cut if cut > 0 else limit
            if cur:
                chunks.append(cur)
                cur = ""
            chunks.append(s[:cut])
            s = s[cut:].strip()
        if len(cur) + len(s) + 1 > limit:
            if cur:
                chunks.append(cur)
            cur = s
        else:
            cur = f"{cur} {s}".strip()
    if cur:
        chunks.append(cur)
    return [c for c in chunks if c.strip()]


def edge_rate(speed: float) -> str:
    pct = round((speed - 1) * 100)
    return f"{'+' if pct >= 0 else ''}{pct}%"


async def synth(text, voice, speed, out_path, retries=3):
    last = None
    for attempt in range(retries):
        try:
            await edge_tts.Communicate(text, voice, rate=edge_rate(speed)).save(out_path)
            return
        except Exception as e:  # network hiccup - retry
            last = e
            await asyncio.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Edge voice generation failed: {last}")


# ---------- UI ----------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AudioReader AI")
        self.geometry("720x600")
        self.minsize(640, 540)
        self.text = ""
        self.src_path = ""
        self.cancel = threading.Event()
        self.worker = None
        self.voice_map = {}
        self._build()
        threading.Thread(target=self._load_voices, daemon=True).start()

    def _build(self):
        pad = {"padx": 12, "pady": 6}
        top = ttk.Frame(self); top.pack(fill="x", **pad)
        ttk.Button(top, text="Open file…", command=self.open_file).pack(side="left")
        self.file_lbl = ttk.Label(top, text="PDF, TXT, MD or DOCX — or paste text below")
        self.file_lbl.pack(side="left", padx=10)

        self.box = tk.Text(self, wrap="word", height=12, undo=True)
        self.box.pack(fill="both", expand=True, **pad)
        self.box.bind("<<Modified>>", self._on_edit)

        opts = ttk.LabelFrame(self, text="Voice & range"); opts.pack(fill="x", **pad)
        ttk.Label(opts, text="Voice").grid(row=0, column=0, sticky="w", padx=8, pady=4)
        self.voice_var = tk.StringVar()
        self.voice_cb = ttk.Combobox(opts, textvariable=self.voice_var, width=48, state="readonly")
        self.voice_cb["values"] = FALLBACK_VOICES
        self.voice_cb.set(FALLBACK_VOICES[0])
        self.voice_cb.grid(row=0, column=1, columnspan=3, sticky="we", padx=8)
        ttk.Button(opts, text="Preview", command=self.preview).grid(row=0, column=4, padx=8)

        ttk.Label(opts, text="Speed").grid(row=1, column=0, sticky="w", padx=8, pady=4)
        self.speed = tk.DoubleVar(value=1.0)
        ttk.Scale(opts, from_=0.5, to=2.0, variable=self.speed, command=self._speed_changed).grid(
            row=1, column=1, columnspan=2, sticky="we", padx=8)
        self.speed_lbl = ttk.Label(opts, text="1.00x", width=6); self.speed_lbl.grid(row=1, column=3)

        ttk.Label(opts, text="From %").grid(row=2, column=0, sticky="w", padx=8, pady=4)
        self.start = tk.IntVar(value=0)
        ttk.Spinbox(opts, from_=0, to=99, textvariable=self.start, width=6).grid(row=2, column=1, sticky="w", padx=8)
        ttk.Label(opts, text="To %").grid(row=2, column=2, sticky="e")
        self.end = tk.IntVar(value=100)
        ttk.Spinbox(opts, from_=1, to=100, textvariable=self.end, width=6).grid(row=2, column=3, sticky="w", padx=8)
        opts.columnconfigure(1, weight=1)

        bar = ttk.Frame(self); bar.pack(fill="x", **pad)
        self.go_btn = ttk.Button(bar, text="Create MP3…", command=self.start_job); self.go_btn.pack(side="left")
        self.cancel_btn = ttk.Button(bar, text="Cancel", command=self.cancel.set, state="disabled")
        self.cancel_btn.pack(side="left", padx=8)
        self.prog = ttk.Progressbar(bar, mode="determinate"); self.prog.pack(side="left", fill="x", expand=True, padx=8)
        self.status = ttk.Label(self, text="Ready", anchor="w"); self.status.pack(fill="x", padx=12, pady=(0, 10))

    # --- helpers
    def _speed_changed(self, _=None):
        self.speed_lbl.config(text=f"{round(self.speed.get(), 2):.2f}x")

    def _on_edit(self, _=None):
        if self.box.edit_modified():
            self.text = self.box.get("1.0", "end").strip()
            self.box.edit_modified(False)

    def set_status(self, msg):
        self.after(0, lambda: self.status.config(text=msg))

    def _load_voices(self):
        try:
            voices = asyncio.run(edge_tts.list_voices())
            wanted = ("en-", "bn-", "es-", "fr-", "de-", "hi-", "ar-", "pt-", "ja-", "zh-")
            names = sorted(v["ShortName"] for v in voices if v["Locale"].startswith(wanted))
            def apply():
                cur = self.voice_var.get()
                self.voice_cb["values"] = names
                self.voice_cb.set(cur if cur in names else names[0])
            self.after(0, apply)
        except Exception:
            self.set_status("Offline? Using built-in voice list.")

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[
            ("Documents", "*.pdf *.txt *.md *.docx"), ("All files", "*.*")])
        if not path:
            return
        try:
            self.set_status("Reading file…"); self.update_idletasks()
            content = read_text(path)
        except Exception as e:
            messagebox.showerror("Could not read file", str(e)); return
        if not content.strip():
            messagebox.showwarning("No text", "No readable text found (scanned PDFs need OCR first).")
            return
        self.src_path = path
        self.file_lbl.config(text=os.path.basename(path))
        self.box.delete("1.0", "end"); self.box.insert("1.0", content)
        self.box.edit_modified(False); self.text = content.strip()
        self.set_status(f"Loaded {len(self.text):,} characters")

    # --- actions
    def preview(self):
        voice = self.voice_var.get()
        def run():
            try:
                self.set_status("Generating preview…")
                path = os.path.join(tempfile.gettempdir(), "audioreader_preview.mp3")
                asyncio.run(synth(f"Hello. This is a preview of the {voice} Microsoft Edge voice.",
                                  voice, self.speed.get(), path))
                os.startfile(path) if sys.platform == "win32" else None
                self.set_status("Preview ready")
            except Exception as e:
                self.set_status(f"Preview failed: {e}")
        threading.Thread(target=run, daemon=True).start()

    def start_job(self):
        self.text = self.box.get("1.0", "end").strip()
        if not self.text:
            messagebox.showinfo("Nothing to read", "Open a file or paste some text first."); return
        s, e = self.start.get(), self.end.get()
        if s >= e:
            messagebox.showerror("Range", "'From %' must be smaller than 'To %'."); return
        base = os.path.splitext(os.path.basename(self.src_path))[0] or "audio"
        out = filedialog.asksaveasfilename(defaultextension=".mp3", initialfile=base + ".mp3",
                                           filetypes=[("MP3 audio", "*.mp3")])
        if not out:
            return
        n = len(self.text)
        part = self.text[int(n * s / 100): int(n * e / 100)]
        chunks = split_text(part)
        if not chunks:
            messagebox.showinfo("Nothing to read", "That range has no text."); return
        self.cancel.clear()
        self.go_btn.config(state="disabled"); self.cancel_btn.config(state="normal")
        self.prog.config(value=0, maximum=len(chunks))
        args = (chunks, self.voice_var.get(), self.speed.get(), out)
        self.worker = threading.Thread(target=self._run_job, args=args, daemon=True)
        self.worker.start()

    def _run_job(self, chunks, voice, speed, out):
        tmpdir = tempfile.mkdtemp(prefix="audioreader_")
        try:
            async def go():
                parts = []
                for i, c in enumerate(chunks):
                    if self.cancel.is_set():
                        raise InterruptedError
                    self.set_status(f"Generating part {i + 1} of {len(chunks)}…")
                    p = os.path.join(tmpdir, f"{i}.mp3")
                    await synth(c, voice, speed, p)
                    parts.append(p)
                    self.after(0, lambda v=i + 1: self.prog.config(value=v))
                with open(out, "wb") as fo:
                    for p in parts:
                        with open(p, "rb") as fi:
                            fo.write(fi.read())
            asyncio.run(go())
            self.set_status(f"Done! Saved to {out}")
            self.after(0, lambda: messagebox.showinfo("Finished", f"Saved:\n{out}"))
        except InterruptedError:
            self.set_status("Cancelled")
        except Exception as e:
            self.set_status("Failed")
            self.after(0, lambda: messagebox.showerror("Generation failed", str(e)))
        finally:
            for f in os.listdir(tmpdir):
                try: os.remove(os.path.join(tmpdir, f))
                except OSError: pass
            try: os.rmdir(tmpdir)
            except OSError: pass
            self.after(0, lambda: (self.go_btn.config(state="normal"), self.cancel_btn.config(state="disabled")))


if __name__ == "__main__":
    App().mainloop()
